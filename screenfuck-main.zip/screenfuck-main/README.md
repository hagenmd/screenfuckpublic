Prototype available at https://screenfuck.vercel.app/
